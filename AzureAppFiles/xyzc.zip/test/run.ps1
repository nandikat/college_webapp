using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

# Interact with query parameters or the body of the request.
$name = $Request.Query.Name
if (-not $name) {
    $name = $Request.Body.Name
}

$body = "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response."

if ($name) {
    $body = "Hello, $name. This HTTP triggered function executed successfully."
}

# Get the authentication token 
#$azContext = Get-AzContext
#$azProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
#$profileClient = New-Object -TypeName Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient -ArgumentList ($azProfile)
#$token = $profileClient.AcquireAccessToken($azContext.Subscription.TenantId)
#$authHeader = @{
#    'Content-Type'='application/json'
#    'Authorization'='Bearer ' + $token.AccessToken
#}
#Write-Output "Authentication Token acquired." # | timestamp
#$restUri='https://management.azure.com/subscriptions/7033d7ca-3a42-476e-a430-8604a5bbb1ab'+'/resourceGroups/prj1'+'/providers/Microsoft.DBForMySQL/servers/ntdb.mysql.database.azure.com/start'+'?api-version=2020-01-01'
#        $response = Invoke-RestMethod -Uri $restUri -Method POST -Headers $authHeader

#Connect-AzAccount
#Register-AzResourceProvider -ProviderNamespace Microsoft.DBforMySQL
#Set-AzContext -SubscriptionId 7033d7ca-3a42-476e-a430-8604a5bbb1ab
#Restart-AzMySqlServer -Name ntdb -ResourceGroupName prj1


$subscriptionids = @"
[
    "7033d7ca-3a42-476e-a430-8604a5bbb1ab"
]
"@ | ConvertFrom-Json

# Convert UTC to West Europe Standard Time zone
#$date = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId([DateTime]::Now,"W. Europe Standard Time")

foreach ($subscriptionid in $subscriptionids) {
# Selecting Azure Sub
Write-Warning $SubscriptionID
Set-AzContext -SubscriptionId $SubscriptionID | Out-Null

$CurrentSub = (Get-AzContext).Subscription.Id
If ($CurrentSub -ne $SubscriptionID) {
Throw "Could not switch to SubscriptionID: $SubscriptionID"
}

#$vms = Get-AzMySqlServer #-Status  #| Where-Object {($_.tags.AutoShutdown -ne $null) -and ($_.tags.AutoStart -ne $null)}
#$now = $date

#Write-Warning "for loop" + $vms


#Start-AzMySqlFlexibleServer -Name "ntdb" -ResourceGroupName "prj1"
Write-Warning "@now"
Start-Sleep -Seconds 120
Write-Warning "@now2"

}


# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::OK
    Body = $body
})
