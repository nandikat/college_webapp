# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}


# Add all your Azure Subscription Ids below
$subscriptionids = @"
[
    "7033d7ca-3a42-476e-a430-8604a5bbb1ab"
]
"@ | ConvertFrom-Json

# Convert UTC to West Europe Standard Time zone
#$date = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId([DateTime]::Now,"W. Europe Standard Time")

foreach ($subscriptionid in $subscriptionids) {
# Selecting Azure Sub
Write-Warning $SubscriptionID
Set-AzContext -SubscriptionId $SubscriptionID | Out-Null

$CurrentSub = (Get-AzContext).Subscription.Id
If ($CurrentSub -ne $SubscriptionID) {
Throw "Could not switch to SubscriptionID: $SubscriptionID"
}

$vms = Get-AzVM -Status  | Where-Object {($_.tags.AutoShutdown -ne $null) -and ($_.tags.AutoStart -ne $null)}
#$now = $date

Write-Warning "for loop"

foreach ($vm in $vms){
# To handle the situations where both stop and start are in the AM or PM, we need to get the correct compare value
#$adddatevalue = ($(get-date $($vm.tags.AutoShutdown)))+($(get-date $($vm.tags.AutoStart))-$(get-date $($vm.tags.AutoShutdown)))
    Write-Warning "$vm.PowerState"
    if (($vm.PowerState -eq 'VM running') ) 
# -and ($now -gt $(get-date $($vm.tags.AutoShutdown))) -and ($now -lt $(get-date $($vm.tags.AutoStart))) ) 
    {
        Stop-AzVM -Name $vm.Name -ResourceGroupName $vm.ResourceGroupName -Confirm:$false -Force
        Write-Warning "Stop VM - $($vm.Name)"
        Stop-AzMySqlFlexibleServer -Name "ntdb" -ResourceGroupName "prj1"
        Write-Warning "Stop DB"

    }
}
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"
