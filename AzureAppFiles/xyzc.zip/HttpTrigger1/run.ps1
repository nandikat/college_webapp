using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

# Interact with query parameters or the body of the request.
$name = $Request.Query.Name
if (-not $name) {
    $name = $Request.Body.Name
}

Write-Warning "parameter :  $name"

# Add all your Azure Subscription Ids below
$subscriptionids = @"
[
    "7033d7ca-3a42-476e-a430-8604a5bbb1ab"
]
"@ | ConvertFrom-Json

# Convert UTC to West Europe Standard Time zone
#$date = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId([DateTime]::Now,"W. Europe Standard Time")

foreach ($subscriptionid in $subscriptionids) {
# Selecting Azure Sub
Write-Warning $SubscriptionID
Set-AzContext -SubscriptionId $SubscriptionID | Out-Null

$CurrentSub = (Get-AzContext).Subscription.Id
If ($CurrentSub -ne $SubscriptionID) {
Throw "Could not switch to SubscriptionID: $SubscriptionID"
}

$vms = Get-AzVM -Status  | Where-Object {($_.tags.AutoShutdown -ne $null) -and ($_.tags.AutoStart -ne $null)}
#$now = $date

Write-Warning "for loop  $name "

foreach ($vm in $vms){
# To handle the situations where both stop and start are in the AM or PM, we need to get the correct compare value
#$adddatevalue = ($(get-date $($vm.tags.AutoShutdown)))+($(get-date $($vm.tags.AutoStart))-$(get-date $($vm.tags.AutoShutdown)))
    Write-Warning "VM STATUS : $vm.PowerState"
    if (($vm.PowerState -eq 'VM running') ) 
# -and ($now -gt $(get-date $($vm.tags.AutoShutdown))) -and ($now -lt $(get-date $($vm.tags.AutoStart))) ) 
    {
        Write-Warning "STOP processes"
        if (($name -eq 'stop')) {
        Stop-AzVM -Name $vm.Name -ResourceGroupName $vm.ResourceGroupName -Confirm:$false -Force
        Write-Warning "Stop VM - $($vm.Name)"
        Stop-AzMySqlFlexibleServer -Name "ntdb" -ResourceGroupName "prj1"
        Write-Warning "Stop DB"
    }
    }
    elseif (($vm.PowerState -ne 'VM running')) 
# -and ($now -gt $(get-date $($vm.tags.AutoStart))) -and (($now -lt $(get-date $($vm.tags.AutoShutdown))) -or ($now -le $adddatevalue)) ) 
    {
        if (($name -ne 'stop')){
            Write-Warning "DB Starting"
            Start-AzMySqlFlexibleServer -Name "ntdb" -ResourceGroupName "prj1"
            Start-Sleep -Seconds 120
            Start-AzVM -Name $vm.Name -ResourceGroupName $vm.ResourceGroupName
    #        Start-AzVM -Name "ntvmt" -ResourceGroupName "prj1"
            Write-Warning "Start VM - $($vm.Name)"
        }
    }

    #email sending
}
}

$body = "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response."

if ($name) {
    $body = "Hello, $name. This HTTP triggered function executed successfully."
}

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::OK
    Body = $body
})
